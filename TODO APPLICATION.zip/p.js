
const http = require('node:http');
const server = http.createServer((req, res)=>{
    res.write("hello backend is running");
    res.end()
})
const PORT=5000;
server.listen(PORT,()=>{
     console.log("backend is running at 5000")
})