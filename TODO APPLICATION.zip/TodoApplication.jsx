import React, { useState } from 'react';

function TodoApplication() {
    const [todo, setTodo] = useState([
        {
            id: 1,
            text: "home work completed",
            completed: false,
            isediting: false
        },
        {
            id: 2,
            text: "check",
            completed: false,
            isediting: false
        },
        {
            id: 3,
            text: "running",
            completed: false,
            isediting: false
        }
    ]);

    const [todoText, setTodoText] = useState("");
    const [editingIndex, setEditingIndex] = useState(0)
    const [editTodoText,setEditTodoText]=useState("")
    const addTodo = (e) => {
        setTodoText(e.target.value);
    };

    const handleSubmit = () => {
        console.log("handleSubmit Triggered");

        // Check if todoText is not empty
        if (todoText.trim() !== "") {
            const temp = { text: todoText, completed: false };
            setTodo([...todo, temp]);
            setTodoText("");  // Reset input field
        }
    };

    console.log(todoText, "todoText");
    const toggleCompleted = (index) => {
        // const temp=[...todo]
        // temp[index].completed = !todo[index].completed
        // setTodo(temp)
        // console.log(todo[index],"index")
        setTodo(
            todo.map((item, i) => i === index ? { ...item, completed: !item.completed } : item))
    }
    const handleDelete = (index) => {
        const temp = [...todo]
        temp.splice(index, 1)
        setTodo(temp)
        // const filteredData = todo.filter((item,i) => i !==index)
        // setTodo(filteredData)
    }
    const handleEdit = (index) => {
        const temp=[...todo]
        temp[index].isediting = true
        setTodo(temp)
        
    }
    const handleCancel = (index) => {
        const temp=[...todo]
        temp[index].isediting = false
        setTodo(temp)
        
    }
    const handleSave = (index) => {
        const temp=[...todo]
        temp[index]={ text : editTodoText, isediting : false, completed : false}
        setTodo(temp)
    }
    console.log(editTodoText,"edit")
    return (
        <div className='d-flex flex-column align-items-center'>
            <h1>Todo Application</h1>
            <div>
                {/* Bind input value to todoText */}
                <input
                    type='text'
                    placeholder='Enter the todo'
                    value={todoText}  // Controlled input field
                    onChange={addTodo}
                />
                <button className='ms-3' onClick={handleSubmit}>Submit</button>
            </div>
            <ul>
                {todo.map((item, index) => (
                    <li key={index} className='ms-3 mt-3'>
                    {
                       item.isediting ?(
                            <>
                                                         
                            <input type="text" placeholder='enter the updated todo'
                            onChange={(e) => setEditTodoText(e.target.value)}/>
                         
                                 <button className='btn btn-primary me-3'onClick = {() => handleSave(index)} >Save</button>
                                 <button className='btn btn-danger' onClick={() => handleCancel(index)}>Cancel</button>
 
                            </>
                        ):
                       <>
                        <span key={item.id} onClick={() =>
                            toggleCompleted(index)} style={{
                                textDecoration: item.completed ? 'line-through' : 'none',
                                cursor: 'pointer'
                            }}>
                            {item.text}
                        </span>
                        <button className="btn btn-primary me-3 ms-3" onClick={() => handleEdit(index)}>Edit</button>
                        <button className="btn btn-danger" onClick={() => handleDelete(index)}>Delete</button>
                        </>   
                    }       
                    </li>
                ))}
        </ul>
        </div >
    );
}

export default TodoApplication;
