const Todo=require("../models/todoModel")
const express=require("express")
const router=express.Router()

router.get("/",async(req,res)=>{
    try{
      const todos=await Todo.find(); 
        res.status(200).json(todos)
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
router.get("/:id",async(req,res)=>{
    try{
        const id=req.params.id;
        console.log(id,"id");
        const todos=await Todo.findById({_id:id}); 
        res.status(200).json(todos)
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
router.put("/:id",async(req,res)=>{
    try{
        const {title,completed}=req.body
        const updatedTodos= await Todo.findByIdAndUpdate(
        req.params.id,
        {title,completed},
        {new:true}
        )
        res.status(200).json(updatedTodos)
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
router.delete("/:id",async(req,res)=>{
    try{
        
        const updatedTodos= await Todo.findByIdAndDelete(
        req.params.id,
        
        )
        res.status(200).json({
            message:"deleted successfully",
            todo:updatedTodos

        })
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
router.delete("/",async(req,res)=>{
    try{
      const todos=await Todo.deleteMany({}); 
        res.status(200).json({
            message:"all todos deletd",
            todo:todos
        })
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
router.post("/",async(req,res)=>{
    try{
        const {title}=req.body;
        const newTodo=new Todo({title});
        const savedTodo= await newTodo.save();
        res.status(201).json(savedTodo)
    }catch(err){
        res.status(500).json({
            message:err.message
        })
    }
})
module.exports=router;